#ifndef _CRC8_
#define _CRC8_
uint8_t    crc8 (uint8_t* data_in, uint16_t number_of_bytes_to_read);
#endif