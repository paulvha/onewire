// pbed


#ifndef _pbedp_
#define _pbedp_

#define DEBUG 1;
#define DEBUG_PIN 17
#define ONEWIRE_PIN  23

// if used with the HS42led library to display
# define _hs42led

# include <stdio.h>
# include <stdlib.h>
# include <stdint.h>
# include <string.h>

// pin modes
#define PullUp      1
#define PullDown    2
#define PullNone    3
#define OpenDrain   4

int ow_init();
void ow_pin_input();
void ow_pin_output();
void ow_pin_output_low();
uint8_t ow_pin;

void wait_ms(uint64_t msec);
void wait_us(uint64_t usec);
void ow_pin_mode(int mode);
void bcm2835_delayMicro(uint64_t micros);
#endif
