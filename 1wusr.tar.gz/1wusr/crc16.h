#ifndef _CRC16_
#define _CRC16_
uint16_t crc16(uint8_t* octets, uint16_t nboctets);
uint8_t ctrl_crc16(uint8_t* octets, uint16_t nboctets);
#endif