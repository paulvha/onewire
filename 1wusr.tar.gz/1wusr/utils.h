#ifndef _utils_
#define _utils_
uint16_t uint8_to_uint16(uint8_t lsb, uint8_t msb);
#endif