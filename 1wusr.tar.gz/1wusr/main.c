/*
 * will capture the temperature from ds18B20 with 1-wire
 * the results are displayed in a loop
 *
 * the temperature can be shown on a HS42056K 4 digit led display
 * include the files in the same directory
 * and make sure to define _hs42led ni pbed.h
 *
 * Paulvha/ march 2016 / version 1.0
 *
 * ***************************************************************************
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 ***************************************************************************
 */



#include "pbed.h"
#include "onewire.h"
#include "DS2450.h"
#include "DS18X20.h"

#ifdef _hs42led
#include "hs42led.h"
#endif


uint8_t gSensorIDs[MAXSENSORS][OW_ROMCODE_SIZE];
uint8_t nSensors;
uint32_t nErreur;
uint32_t nErreur_DS18X20;
uint32_t nErreur_DS2450;
uint32_t nErreur_CRC;
uint32_t nErreur_BUS;
uint32_t nErreur_DS2450_START;
uint32_t nErreur_BUSY;
uint32_t nErreur_RESET;
uint32_t nMesure;
uint32_t micro_seconds;

/**
*     @brief DS18X20_show_temp
*    @param  [in] id[] = rom_code
*    @param  [in] n number of id[n]
*    @param  [out] text temp in degre celsius

*     @date 20/06/2011
*/
void DS18X20_show_temp(uint8_t subzero, uint8_t cel, uint8_t cel_frac_bits,char *text) {
    uint16_t decicelsius;
    char s[10];
    float temperature;
    sprintf(text,"");
    sprintf(s,"%s", (subzero)?"-":"+");
    strcat(text,s);
    decicelsius = DS18X20_temp_to_decicel(subzero, cel, cel_frac_bits);
    temperature = decicelsius;
    temperature = temperature/10;
    sprintf(s,"%4.1f", temperature);
    strcat(text,s);

}
#ifdef _hs42led
/*
 * display degrees on the digits
 * string = string to display
 * len = length of the string
 */
void display_string( char buf[], int len)
{
    int lp=0, digit = 0;

    for(lp=0; lp < len; lp++)
    {
        // set dot on previous digit
        if (buf[lp] == '.') set_dot(digit-1,SET);

        // skip the + sign (can't display)
        else if (buf[lp] == '+')
            continue;

        else
            set_char(digit++ ,buf[lp]);

    }
    // display degrees
    set_char(3,'@');
}

#endif


int main(void) {
    uint8_t sp[25];
    uint8_t num_sensor;
    uint8_t subzero, cel, cel_frac_bits;
    uint8_t i;
    char text[25];
    char j;
    printf("version 2016-03-27\n");
    printf("1 wire interface !\n");

    if (ow_init())
    {
        printf("could not initiatilize the GPIO\n");
        exit(1);
    }
#ifdef _hs42led
    printf("using hs42led library\n");

    /* initialise and set control-c on.*/
    // MUST ALWAYS BE DONE FIRST !!
    do_init(CTRLC);

    // set for higher refresh rate on the leds
    set_refresh(5);
#endif
    // reset sensor
    for (num_sensor=0; num_sensor<nSensors; ++num_sensor)
        gSensorIDs[num_sensor][0] = 0;

    // look for sensors
    if (search_sensors(&nSensors,&gSensorIDs[0][0])) {
        printf("no Sensors found\n");
        return -1;
    } else {
        printf("Sensors found : %d\n", nSensors);

        for (num_sensor=0; num_sensor<nSensors; ++num_sensor) {
            char text_id[25];
            ow_show_id( &gSensorIDs[num_sensor][0], OW_ROMCODE_SIZE,text_id );
            printf("%s Sensor # %d is a ",text_id, num_sensor+1);

            //DS18X20
            if (( gSensorIDs[num_sensor][0] == DS18S20_ID) || ( gSensorIDs[num_sensor][0] == DS18B20_ID)) {
                if ( gSensorIDs[num_sensor][0] == DS18S20_ID)
                    printf("DS18S20/DS1820 ");
                if ( gSensorIDs[num_sensor][0] == DS18B20_ID)
                    printf("DS18B20 ");
                if ( DS18X20_get_power_status( &gSensorIDs[num_sensor][0] ) ==
                        DS18X20_POWER_PARASITE )
                    printf( "parasite" );
                else printf( "externally" );
                printf( " powered\n" );
            }

            //DS2450
            if ( gSensorIDs[num_sensor][0] == DS2450_ID) {
                printf("DS2450 ");
                for (i=0 ; i< DS2450_SP_SIZE; i++ )     // DS2450 POWER extern
                    sp[i]=0;
                sp[4]=0x40;
                if (DS2450_configure_page(&gSensorIDs[num_sensor][0], DS2450_PAGE3,&sp[0]))
                    printf("CRC Error conf page \n");
                if (DS2450_read_page(&gSensorIDs[num_sensor][0], DS2450_PAGE3,&sp[0]))
                    ;
                else
                    printf( "\n" );
                for (j=0 ; i< DS2450_SP_SIZE; i++ )
                    printf(":%2.2X",sp[i]);
                printf( "\n" );
                if (DS2450_configure_channel_ADC(&gSensorIDs[num_sensor][0],DS2450_ADCA,DS2450_12_BIT ,DS2450_IR_5V1))
                    printf("CRC Error conf ADC\n");
                if (DS2450_configure_channel_ADC(&gSensorIDs[num_sensor][0],DS2450_ADCB,DS2450_1_BIT ,DS2450_IR_5V1))
                    printf("CRC Error conf ADC\n");
                if (DS2450_configure_channel_ADC(&gSensorIDs[num_sensor][0],DS2450_ADCC,DS2450_1_BIT,DS2450_IR_5V1))
                    printf("CRC Error conf ADC\n");
                if (DS2450_configure_channel_ADC(&gSensorIDs[num_sensor][0],DS2450_ADCD,DS2450_1_BIT,DS2450_IR_5V1))
                    printf("CRC Error conf ADC\n");
                uint16_t adc[4];
                if (DS2450_start_and_read_ADC(&gSensorIDs[num_sensor][0], &adc[0]))
                    printf("CRC Error read ADC\n");
                for (i=0; i<4; ++i )
                    printf(" adc%d:%X %f |",i,adc[i],adc[i]*5.1/65535);
                printf("\n");
            }

        }
        nErreur=0;
        nErreur_CRC=0;
        nErreur_BUS=0;
        nErreur_DS18X20=0;
        nErreur_DS2450=0;
        nErreur_DS2450_START=0;
        nErreur_BUSY=0;
        nErreur_RESET=0;
        nMesure=0;

        while (1) {

            bcm2835_delayMicro(1000000);

            nMesure++;
            printf("Measured: %d, error: %d\t",nMesure,nErreur);

            switch (DS18X20_start_meas(DS18X20_POWER_EXTERN, 0 )) { // start measure ALL DS18X20
                case DS18X20_OK :
                    wait_ms(DS18B20_TCONV_12BIT);
                    break;
                case DS18X20_START_FAIL:
                    nErreur++;
                    nErreur_DS18X20++;
                    printf("sensor DS18X20 : Start measurement. failed \n");
                    break;
            }

            for (num_sensor=0; num_sensor<nSensors; ++num_sensor) {

                // last one found.
                if (gSensorIDs[num_sensor][0] == 0)
                    break;

                //DS2450
                if (gSensorIDs[num_sensor][0] == DS2450_ID) {

                    uint16_t adc[4];
                    if (DS2450_start_and_read_ADC(&gSensorIDs[num_sensor][0], &adc[0])) // 3 essais avant erreur
                        if (DS2450_start_and_read_ADC(&gSensorIDs[num_sensor][0], &adc[0]))
                            switch (DS2450_start_and_read_ADC(&gSensorIDs[num_sensor][0], &adc[0])) {
                                case OW_OK:

                                    break;
                                case OW_BUSY:
                                    nErreur++;
                                    nErreur_DS2450++;
                                    nErreur_BUSY++;

                                    break;
                                case OW_ERROR:
                                    nErreur++;
                                    nErreur_DS2450++;
                                    nErreur_BUS++;

                                    break;
                                case OW_ERROR_CRC:
                                    nErreur++;
                                    nErreur_DS2450++;
                                    nErreur_CRC++;
                                    printf("Error:%d\n",nErreur);
                                    printf("ErrorDS2450_busy:%d\n",nErreur_BUSY);
                                    printf("ErrorDS2450_start:%d\n",nErreur_DS2450_START);
                                    printf("ErrorDS2450:%d\n",nErreur_DS2450);
                                    printf("ErrorDS18X20:%d\n",nErreur_DS18X20);
                                    printf("ErrorCRC:%d\n",nErreur_CRC);
                                    printf("ErrorBUS:%d\n",nErreur_BUS);
                                    printf("ErrorRESET:%d\n",nErreur_RESET);
                                    printf("Mesure:%d\n",nMesure);
                                    break;
                                case OW_SHORT_CIRCUIT:
                                    nErreur++;
                                    nErreur_DS2450++;
                                    nErreur_RESET++;
                                    break;
                                case OW_ERROR_BAD_ID:

                                    break;
                            }

                    for (i=0; i<4; ++i )
                        printf(" adc%d:%X %f |",i,adc[i],adc[i]*5.1/65535);
                    printf("\n");
                }

                //TEMP DS1820
                if ( (gSensorIDs[num_sensor][0] == DS18S20_ID) ||( gSensorIDs[num_sensor][0] == DS18B20_ID))
                    switch (DS18X20_read_meas( &gSensorIDs[num_sensor][0], &subzero, &cel, &cel_frac_bits)) {
                        case DS18X20_OK :
                            DS18X20_show_temp(subzero, cel, cel_frac_bits,text);
                            printf("sensor %d : %s\n",num_sensor+1,text);
#ifdef _hs42led
                            display_string(text, sizeof(text));
#endif
                            break;
                        case OW_ERROR:
                            nErreur++;
                            nErreur_BUS++;
                            nErreur_DS18X20++;
                            printf("sensor %d : BUS Error\n",num_sensor+1);
                            break;
                        case DS18X20_ERROR_CRC:
                            nErreur++;
                            nErreur_DS18X20++;
                            nErreur_CRC++;
                            printf("sensor %d : CRC Error\n",num_sensor+1);
                            break;
                    }

            }
#ifdef _hs42led
        capture_busy=0;
#endif
        }
    }
}
