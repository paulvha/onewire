// low level GPIO routines

# include "pbed.h"
# include "bcm2835.h"

uint8_t ow_pin;

/* same as BCM2835_delayMicroseconds BUT without nano*/
void bcm2835_delayMicro(uint64_t micros)
{
    uint64_t        start;

    start =  bcm2835_st_read();

    bcm2835_st_delay(start, micros);
}

// wait micro seconds
void wait_us(uint64_t usec)
{
    bcm2835_delayMicro (usec);
}

// wait milli seconds
void wait_ms(uint64_t msec)
{
    bcm2835_delayMicro (msec * 1000);
}

// set pin as input & and read input
void ow_pin_input()
{
    int i ;  // for debug only : pulse time.

    bcm2835_gpio_fsel(ONEWIRE_PIN, BCM2835_GPIO_FSEL_INPT);

#ifdef DEBUG
    bcm2835_gpio_write(DEBUG_PIN, HIGH);
    ow_pin = bcm2835_gpio_lev(ONEWIRE_PIN);
    for (i=0; i < 100 ; i++);
    bcm2835_gpio_write(DEBUG_PIN,LOW);
#else
    ow_pin = bcm2835_gpio_lev(ONEWIRE_PIN);
#endif
}
// set pin as input
void ow_pin_output_low()
{
    bcm2835_gpio_fsel(ONEWIRE_PIN, BCM2835_GPIO_FSEL_INPT);
}

int ow_init()
{
    bcm2835_init();

#ifdef DEBUG
        printf("Debug read pulse on pin %d\n", DEBUG_PIN);
        bcm2835_gpio_fsel(DEBUG_PIN, BCM2835_GPIO_FSEL_OUTP);
        bcm2835_gpio_write(DEBUG_PIN,LOW);

#endif
}

// set pin at output & low
void ow_pin_output()
{
    bcm2835_gpio_fsel(ONEWIRE_PIN, BCM2835_GPIO_FSEL_OUTP);
    bcm2835_gpio_write(ONEWIRE_PIN,LOW);
}

// set pull_up or not
void ow_pin_mode(int mode)
{
    switch(mode){

        case PullUp:
            bcm2835_gpio_set_pud(ONEWIRE_PIN, BCM2835_GPIO_PUD_UP);
            break;
        case PullDown:
            bcm2835_gpio_set_pud(ONEWIRE_PIN, BCM2835_GPIO_PUD_DOWN);
            break;
        case OpenDrain:
        case PullNone:
            bcm2835_gpio_set_pud(ONEWIRE_PIN, BCM2835_GPIO_PUD_OFF);
        }
}
